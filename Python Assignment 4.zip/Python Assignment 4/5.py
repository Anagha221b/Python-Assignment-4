#This function will return the area of a rectangle with and without width arguments
def calculate_area(length, width=5):
    area_of_rectangle=length*width
    return area_of_rectangle
length=float(input("Enter the length of the rectangle: "))
print(f"Area of rectangle without width argument: {calculate_area(length)}")
print(f"Area of rectangle with width argument: {calculate_area(length,8)}")