# This function returns the maximum numbers in the list using loop iterations
def find_maximum(numbers):
    max_num=-1
    for i in numbers:
        if i>max_num:
            max_num=i
    return max_num

numbers=[34,23,12,66,34,45,67]
print(f"The maximum number in the list is: {find_maximum(numbers)}")
        