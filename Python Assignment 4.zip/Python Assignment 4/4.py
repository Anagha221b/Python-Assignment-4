#Demonstration of local and global variable
var="I am global variable" #global variable

def local_scope():
    var="I am local variable" #local variable
    print(var)

local_scope()
print(var)