#Function greet() to take name as input and print greeting with input name.
def greet(name):
    print(f"Hello, {name}!")
greet(input("Enter your name: "))