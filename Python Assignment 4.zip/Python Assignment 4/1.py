# using len() to find the length of a list
my_list=[1,2,3,4,5,6,7,8,9]
length_of_list=len(my_list)
print(f"The length of the lsit is: {length_of_list}")